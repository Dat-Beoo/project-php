<?php include 'header.php' ?>
      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
        </div>
        <div class="box-body">
          <table class="table table-hover">
          	<thead>
          		<tr>
          			<th>ID</th>
          			<th>Tên danh mục</th>
          			<th>Trạng thái</th>
          			<th></th>
          		</tr>
          	</thead>
          	<tbody>
          		<tr>
          			<td>1</td>
          			<td>1</td>
          			<td>1</td>
          			<td>
          				<a href="" class="btn btn-xs btn-primary">Sửa</a>
          				<a href="" class="btn btn-xs btn-danger">Xóa</a>
          			</td>
          		</tr>
          	</tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
<?php include 'footer.php' ?>